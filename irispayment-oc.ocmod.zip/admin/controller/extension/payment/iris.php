<?php
class ControllerExtensionPaymentIris extends Controller {
  private $error = array();
  public function index() {
    $this->load->language('extension/payment/iris');

	$this->document->setTitle($this->language->get('heading_title'));

    $this->load->model('setting/setting');

	if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
		$this->model_setting_setting->editSetting('payment_iris', $this->request->post);
		$this->session->data['success'] = $this->language->get('text_success');
		$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
	}

	if (isset($this->error['merchant_key'])) {
		$data['error_merchant_key'] = $this->error['merchant_key'];
	} else {
		$data['error_merchant_key'] = '';
	}

	if (isset($this->error['merchant_iban'])) {
		$data['error_merchant_iban'] = $this->error['merchant_iban'];
	} else {
		$data['error_merchant_iban'] = '';
	}

	if (isset($this->error['error_name'])) {
		$data['error_name'] = $this->error['error_name'];
	} else {
		$data['error_name'] = '';
	}
	if (isset($this->error['error_description'])) {
		$data['error_description'] = $this->error['error_description'];
	} else {
		$data['error_description'] = '';
	}
	


	$data['breadcrumbs'] = array();

	$data['breadcrumbs'][] = array(
		'text' => $this->language->get('text_home'),
		'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
	);

	$data['breadcrumbs'][] = array(
		'text' => $this->language->get('text_extension'),
		'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
	);

	$data['breadcrumbs'][] = array(
		'text' => $this->language->get('heading_title'),
		'href' => $this->url->link('extension/payment/iris', 'user_token=' . $this->session->data['user_token'], true)
	);

	if (isset($this->request->post['payment_iris_merchant_key'])) {
		$data['payment_iris_name'] = $this->request->post['payment_iris_name'];
		$data['payment_iris_description'] = $this->request->post['payment_iris_description'];
		$data['payment_iris_merchant_key'] = $this->request->post['payment_iris_merchant_key'];
		$data['payment_iris_merchant_iban'] = $this->request->post['payment_iris_merchant_iban'];
		$data['payment_iris_testmode'] = isset($this->request->post['payment_iris_testmode'])?1:0;
		$data['payment_iris_ordstatus'] = isset($this->request->post['payment_iris_ordstatus'])?1:0;
	} else {
		$data['payment_iris_name'] = $this->config->get('payment_iris_name');
		$data['payment_iris_description'] = $this->config->get('payment_iris_description');
		$data['payment_iris_merchant_key'] = $this->config->get('payment_iris_merchant_key');
		$data['payment_iris_merchant_iban'] = $this->config->get('payment_iris_merchant_iban');
		$data['payment_iris_testmode'] = $this->config->get('payment_iris_testmode');
		$data['payment_iris_ordstatus'] = $this->config->get('payment_iris_ordstatus');
	}

	$data['payment_iris_testmode_checked'] = $data['payment_iris_testmode']?' checked':'';

	$this->load->model('localisation/order_status');
	$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

	$data['header'] = $this->load->controller('common/header');
	$data['column_left'] = $this->load->controller('common/column_left');
	$data['footer'] = $this->load->controller('common/footer');

    $this->load->model('localisation/order_status');
           
    $this->response->setOutput($this->load->view('extension/payment/iris', $data));
  }

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/iris')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['payment_iris_name']) {
			$this->error['error_name'] = $this->language->get('err_name');
		}

		if (!$this->request->post['payment_iris_description']) {
			$this->error['error_description'] = $this->language->get('err_description');
		}

		if (!$this->request->post['payment_iris_merchant_key']) {
			$this->error['merchant_key'] = $this->language->get('err_merchant_key');
		}

		if (!$this->request->post['payment_iris_merchant_iban']) {
			$this->error['merchant_iban'] = $this->language->get('err_merchant_iban');
		}

		return !$this->error;
	}
}
