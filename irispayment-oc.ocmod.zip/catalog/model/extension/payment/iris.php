<?php
class ModelExtensionPaymentIris extends Model {
	public function getMethod($address, $total) {
		$this->load->language('extension/payment/iris');

		$method_data = array(
			'code'       => 'iris',
			'title'      => $this->config->get('payment_iris_name'),
			'terms'      => '',
			'sort_order' => $this->config->get('payment_iris_sort_order')
		);

		return $method_data;
	}
}