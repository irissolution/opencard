<?php
class ControllerExtensionPaymentIris extends Controller {
	public function index() {
		$this->load->model('checkout/order');
		if(!isset($this->session->data['order_id'])) {
			return false;
		}
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		$data['payment_iris_name'] = $this->config->get('payment_iris_name');
		$data['payment_iris_description'] = $this->config->get('payment_iris_description');
		$data['payment_iris_merchant_key'] = $this->config->get('payment_iris_merchant_key');
		$data['payment_iris_merchant_iban'] = $this->config->get('payment_iris_merchant_iban');
		$data['payment_iris_testmode'] = $this->config->get('payment_iris_testmode');
		//$order_info['currency_code'] = 'EUR';
		$args = [
			'currency'=>$order_info['currency_code'],
			'name'=>$data['payment_iris_name'],
			'description'=>$data['payment_iris_description'],
			'redirectUrl'=>$this->url->link('checkout/success'),
			'orderId'=>$this->session->data['order_id'],
			'sum'=>$order_info['total'],
			'toIban'=>$data['payment_iris_merchant_iban'],
			'hookUrl'=>$this->url->link('extension/payment/iris/callback').'/?id='.$this->session->data['order_id'],
			'lang'=>'bg'
		];
		if ($data['payment_iris_testmode']) $url = 'https://payperclick.infn.dev/backend/payment/external/';
		else $url = 'https://paybyclick.irispay.bg/backend/payment/external/';
		//echo $this->url->link('extension/payment/iris/callback').'?id='.$this->session->data['order_id'];
		$resp = $this->HTTPPostJSON($url.$data['payment_iris_merchant_key'], $args);
		$resp = json_decode($resp);
		if ($resp->message) $data['error'] = $resp->message;
		else {
			$data['action'] = $resp->paymentLink;
		}

		//if (isset($resp->paymentLink)) {
			//$this->response->redirect($resp->paymentLink);
		//}
		return $this->load->view('extension/payment/iris', $data);
	}

	public function callback() {
		$this->log->write('iris pay notify:');
		//fwrite(fopen('ttt.txt', 'w'), serialize($_GET).'---'.seri	alize($_POST).'---'.$this->session->data['order_id']);
		if ($_GET['status'] == 'CONFIRMED') {
			$this->load->model('checkout/order');
			$orderid = explode('?id=', $_GET['route'])[1];
			$this->model_checkout_order->addOrderHistory($orderid, $this->config->get('payment_iris_ordstatus'));
		}
	}

	public function HTTPPostJSON($url, $postdata=0) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		if (is_array($postdata)) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}

}