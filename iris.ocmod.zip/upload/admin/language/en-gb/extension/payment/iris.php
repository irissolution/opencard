<?php
$_['heading_title'] = 'Iris Payment Method';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_iris']	 = '<a href="https://www.irisbgsf.com" target="_blank"><img src="view/image/payment/iris.jpg" alt="BluePay Hosted Form" title="Iris Open Banking" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_config_one'] = 'Parameter one';
$_['text_config_two'] = 'Parameter Two';
$_['entry_status'] = 'Status:';
$_['entry_order_status'] = 'Order Status:';
$_['text_button_save'] = 'Save';
$_['text_button_cancel'] = 'Cancel';
$_['entry_email'] = 'Email';
$_['text_success'] = 'SUCCESS';
$_['error_permission'] = 'NOPERM';
$_['error_email'] = 'ERRMAIL';

$_['entry_order_status'] = 'Order Status after Payment';

$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';

$_['test_mode'] = 'Test Mode';
$_['test_mode_descr'] = 'Try the payment in test mode';

$_['lbl_name'] = 'Short Description of the payment';
$_['err_name'] = 'Please fill in Short Description';
$_['hint_name'] = 'Will be present in the fund transfer form of the bank in the description placeholder, up to 34 symbols.';

$_['lbl_description'] = 'Full Description of the payment';
$_['err_description'] = 'Please fill in Full Description';
$_['hint_description'] = 'Will be present only in the IRIS Solutions systems, up to 240 symbols.';

$_['lbl_merchant_key'] = 'Merchant Key';
$_['err_merchant_key'] = 'Please fill in Merchant Key';
$_['hint_merchant_key'] = 'Your Merchant Key, obtained from your IRIS Solutions, Merchant portal account.';

$_['lbl_merchant_iban'] = 'Merchant Account (IBAN)';
$_['err_merchant_iban'] = 'Please fill in Merchant IBAN';
$_['hint_merchant_iban'] = 'Your Merchant Account, obtained from your IRIS Solutions, Merchant portal account.';

?>