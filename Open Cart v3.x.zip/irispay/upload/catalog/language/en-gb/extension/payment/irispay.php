<?php
$_['heading_title']  = 'Iris Pay (Open Banking)';
$_['button_confirm'] = 'Confirm Order & Pay with Iris Pay';
$_['text_loading']   = 'Initializing payment...';
