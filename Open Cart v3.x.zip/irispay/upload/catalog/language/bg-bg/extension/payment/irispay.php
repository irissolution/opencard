<?php
$_['heading_title']  = 'Iris Pay (Open Banking)';
$_['button_confirm'] = 'Потвърди поръчката и плати с Iris Pay';
$_['text_loading']   = 'Инициализация на плащане...';
