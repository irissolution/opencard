<?php
/**
 * IRIS Pay Payment Module - Catalog Model
 * Compatible with OpenCart 3.x
 */
class ModelExtensionPaymentIrispay extends Model
{
    public function getMethod($address, $total)
    {
        $this->load->language('extension/payment/irispay');

        if (!$this->config->get('payment_irispay_status')) {
            return [];
        }

        $title = $this->language->get('heading_title');

        $method_data = [
            'code'       => 'irispay',
            'title'      => '<img src="https://irispay.bg/resource/public/image/iris-logo.svg" alt="Iris Pay" style="height:24px;vertical-align:middle;margin-right:8px;" /> ' . $title,
            'terms'      => '',
            'sort_order' => (int)$this->config->get('payment_irispay_sort_order')
        ];

        return $method_data;
    }
}
