<?php
/**
 * IRIS Pay Payment Module - Admin Controller
 * Compatible with OpenCart 3.x
 */
class ControllerExtensionPaymentIrispay extends Controller
{
    private $error = [];

    public function index()
    {
        $this->load->language('extension/payment/irispay');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('payment_irispay', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['api_key'])) {
            $data['error_api_key'] = $this->error['api_key'];
        } else {
            $data['error_api_key'] = '';
        }

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/payment/irispay', 'user_token=' . $this->session->data['user_token'], true)
        ];

        $data['action'] = $this->url->link('extension/payment/irispay', 'user_token=' . $this->session->data['user_token'], true);
        $data['back']   = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

        $data['payment_irispay_api_key']         = $this->config->get('payment_irispay_api_key');
        $data['payment_irispay_environment']      = $this->config->get('payment_irispay_environment') ?: 'sandbox';
        $data['payment_irispay_sdk_version']      = $this->config->get('payment_irispay_sdk_version') ?: 'prod';
        $data['payment_irispay_order_status_id']  = $this->config->get('payment_irispay_order_status_id');
        $data['payment_irispay_status']           = $this->config->get('payment_irispay_status');
        $data['payment_irispay_sort_order']       = $this->config->get('payment_irispay_sort_order');

        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/payment/irispay', $data));
    }

    public function install()
    {
        $this->load->model('setting/event');
        $this->model_setting_event->addEvent(
            'irispay_sdk',
            'Catalog IRIS Pay SDK Injection',
            'catalog/view/common/header/before',
            'extension/payment/irispay/header',
            1,
            0
        );
    }

    public function uninstall()
    {
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('irispay_sdk');
    }

    protected function validate()
    {
        if (!$this->user->hasPermission('modify', 'extension/payment/irispay')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['payment_irispay_api_key']) {
            $this->error['api_key'] = $this->language->get('error_api_key');
        }

        return !$this->error;
    }
}
