<?php
// Heading
$_['heading_title']    = 'Iris Pay (Open Banking)';

// Text
$_['text_edit']        = 'Edit Iris Pay Settings';
$_['text_extension']   = 'Extensions';
$_['text_home']        = 'Home';
$_['text_success']     = 'Success: You have modified Iris Pay settings!';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['text_sandbox']     = 'Sandbox';
$_['text_live']        = 'Live';
$_['text_sdk_prod']    = 'Production (Iris Pay)';
$_['text_sdk_dev']     = 'Developer (Infn Dev)';

// Entry
$_['entry_api_key']      = 'API Key';
$_['entry_environment']  = 'Environment';
$_['entry_sdk_version']  = 'SDK Version';
$_['entry_order_status'] = 'Order Status (on payment)';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sort Order';

// Button
$_['button_save'] = 'Save';
$_['button_back'] = 'Back';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Iris Pay!';
$_['error_api_key']    = 'Warning: API Key is required!';
