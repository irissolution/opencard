<?php
// Heading
$_['heading_title']    = 'Iris Pay (Open Banking)';

// Text
$_['text_edit']        = 'Редактиране на настройки на Iris Pay';
$_['text_extension']   = 'Разширения';
$_['text_home']        = 'Начало';
$_['text_success']     = 'Успех: Настройките на Iris Pay бяха запазени!';
$_['text_enabled']     = 'Включено';
$_['text_disabled']    = 'Изключено';
$_['text_sandbox']     = 'Тестова среда (Sandbox)';
$_['text_live']        = 'Реална среда (Live)';
$_['text_sdk_prod']    = 'Производствена (Iris Pay)';
$_['text_sdk_dev']     = 'Разработка (Infn Dev)';

// Entry
$_['entry_api_key']      = 'API Ключ';
$_['entry_environment']  = 'Среда';
$_['entry_sdk_version']  = 'Версия на SDK';
$_['entry_order_status'] = 'Статус на поръчка (при плащане)';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Наредба';

// Button
$_['button_save'] = 'Запази';
$_['button_back'] = 'Назад';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на Iris Pay!';
$_['error_api_key']    = 'Внимание: API Ключът е задължителен!';
