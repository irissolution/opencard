<?php
namespace Opencart\Catalog\Model\Extension\Irispay\Payment;

class Irispay extends \Opencart\System\Engine\Model
{
    /**
     * Get Methods
     *
     * @param array<string, mixed> $address array of data
     *
     * @return array<string, mixed>
     */
    public function getMethods(array $address = []): array
    {
        $this->load->language('extension/irispay/payment/irispay');

        if (!$this->config->get('payment_irispay_status')) {
            $status = false;
        } else {
            $status = true;
        }

        $method_data = [];

        if ($status) {
            $_name = $this->language->get('heading_title');
            if (strpos($_name, 'heading_title') !== false) {
                $_name = 'Iris Pay';
            }
            $option_data['irispay'] = [
                'code' => 'irispay.irispay',
                'name' => '<img src="https://irispay.bg/resource/public/image/iris-logo.svg" alt="Iris Pay" style="height: 24px; vertical-align: middle; margin-right: 8px;" /> ' . $_name
            ];

            $method_data = [
                'code' => 'irispay',
                'name' => 'Iris Pay',
                'option' => $option_data,
                'sort_order' => (int) $this->config->get('payment_irispay_sort_order')
            ];
        }

        return $method_data;
    }
}
