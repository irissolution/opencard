<?php
namespace Opencart\Catalog\Controller\Extension\Irispay\Payment;

class Irispay extends \Opencart\System\Engine\Controller
{
    public function header(&$route, &$args, &$output): void
    {
        $sdk_urls = $this->getSdkUrls();
        $this->document->addScript($sdk_urls['js']);
        $this->document->addStyle($sdk_urls['css']);
    }


    public function index(): string
    {
        $this->load->language('extension/irispay/payment/irispay');
        $this->load->model('checkout/order');

        if (!isset($this->session->data['order_id'])) {
            return '';
        }

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

        // 1. Prepare Hook Data & URLs
        $state = 'oc_cart_' . $this->session->data['order_id'] . '_' . time();
        $webhook_url = $this->url->link('extension/irispay/payment/irispay|webhook', 'state=' . $state, true);
        $success_url = $this->url->link('checkout/success', '', true);
        $error_url = $this->url->link('checkout/checkout', '', true);

        $total_sum = (float) $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);

        // 2. Get Hook Hash & details dynamically
        $hook_data = $this->getHookHash($order_info['currency_code'], $order_info['order_id'], $total_sum, $webhook_url);
        if (!$hook_data || !isset($hook_data['hookHash'])) {
            return '<div class="alert alert-danger">Error initializing payment (HookHash). Please try again or use another payment method.</div>';
        }
        $hook_hash = $hook_data['hookHash'];
        $public_hash = $hook_data['publicHash'];
        $to_iban = $hook_data['iban'];
        $merchant_name = $hook_data['merchantName'];

        // 3. Get User Hash
        $user_hash = $this->getUserHash($public_hash);
        if (!$user_hash) {
            return '<div class="alert alert-danger">Error initializing payment (UserHash). Please try again or use another payment method.</div>';
        }

        // Clean up any old hooks for this order to avoid confusion
        $this->db->query("DELETE FROM " . DB_PREFIX . "setting WHERE `key` = 'hook_" . (int) $this->session->data['order_id'] . "'");

        // Store hook_hash in DB to verify later
        $this->db->query("INSERT INTO " . DB_PREFIX . "setting SET `store_id` = 0, `code` = 'irispay_hook', `key` = 'hook_" . (int) $this->session->data['order_id'] . "', `value` = '" . $this->db->escape($hook_hash) . "'");

        // 4. Prepare Payment Data
        $payment_data = [
            'currency' => $order_info['currency_code'],
            'description' => (string) $order_info['order_id'],
            'sum' => $total_sum,
            'toIban' => $to_iban,
            'publicHash' => $public_hash,
            'merchant' => $merchant_name
        ];

        $data['payment_data_b64'] = base64_encode(json_encode($payment_data));
        $data['hookhash'] = $hook_hash;
        $data['userhash'] = $user_hash;
        $data['backend'] = $this->getBackendUrl();
        $data['order_id'] = (int) $this->session->data['order_id'];
        $data['poll_url'] = $this->url->link('extension/irispay/payment/irispay|status', 'order_id=' . $data['order_id'], true);
        $data['confirm_url'] = $this->url->link('extension/irispay/payment/irispay|confirm', '', true);
        $data['success_url'] = $success_url;
        $data['error_url'] = $error_url;
        $data['language'] = $this->config->get('config_language');

        $sdk_urls = $this->getSdkUrls();
        $data['sdk_js'] = $sdk_urls['js'];
        $data['sdk_css'] = $sdk_urls['css'];

        return $this->load->view('extension/irispay/payment/irispay', $data);
    }

    public function confirm(): void
    {
        $this->load->language('extension/irispay/payment/irispay');
        $json = [];

        if (isset($this->session->data['order_id'])) {
            $this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

            if (!$order_info) {
                $json['error'] = 'Order not found';
            }
        } else {
            $json['error'] = 'Session expired';
        }

        if (!$json) {
            // Mark order as Pending (1) before payment starts
            $this->model_checkout_order->addHistory($this->session->data['order_id'], 1, 'IRIS Pay: Order confirmed by customer. Awaiting payment...');
            $json['success'] = true;
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }


    public function status(): void
    {
        $json = ['status' => 'pending'];

        if (isset($this->request->get['order_id'])) {
            $order_id = (int) $this->request->get['order_id'];
            $this->log("[STATUS] Polling Order #$order_id");

            $this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($order_id);

            if ($order_info) {
                $target_status = (int) $this->config->get('payment_irispay_order_status_id');

                if ($order_info['order_status_id'] == $target_status) {
                    $this->log("[STATUS] Success for #$order_id (already updated).");
                    $json = [
                        'status' => 'success',
                        'redirect' => $this->url->link('checkout/success', '', true)
                    ];
                } else {
                    $json = ['status' => 'pending'];
                }
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function webhook(): void
    {
        $this->log("[WEBHOOK] Call started");
        if (isset($this->request->get['state'])) {
            $parts = explode('_', $this->request->get['state']);
            if (count($parts) >= 3 && $parts[0] == 'oc' && $parts[1] == 'cart') {
                $order_id = (int) $parts[2];
                $this->log("[WEBHOOK] Found Order #$order_id");

                $query = $this->db->query("SELECT `value` FROM " . DB_PREFIX . "setting WHERE `key` = 'hook_" . $order_id . "' ORDER BY `setting_id` DESC LIMIT 1");
                if ($query->num_rows) {
                    $hook_hash = $query->row['value'];
                    
                    // Temporarily read status from query parameters
                    $status = $this->request->get['status'] ?? '';

                    if ($status === 'CONFIRMED') {
                        $this->load->model('checkout/order');
                        $order_info = $this->model_checkout_order->getOrder($order_id);
                        $target_status = (int) $this->config->get('payment_irispay_order_status_id');

                        if ($order_info && $order_info['order_status_id'] != $target_status) {
                            $this->model_checkout_order->addHistory($order_id, $target_status, 'IRIS Pay Webhook: Payment confirmed.', true);
                            $this->log("[WEBHOOK] Successfully updated #$order_id");
                        }
                        echo "OK";
                        return;
                    }
                }
            }
        }
        echo "FAIL";
    }

    private function log($message)
    {
        $log_file = DIR_STORAGE . 'logs/irispay.log';
        file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
    }


    // API Helpers (reused logic from PrestaShop)
    private function getBackendUrl()
    {
        return $this->config->get('payment_irispay_environment') === 'live' ? 'https://developer.irispay.bg/' : 'https://developer.sandbox.irispay.bg/';
    }

    private function getPayByClickBackendUrl()
    {
        return $this->config->get('payment_irispay_environment') === 'live' ? 'https://paybyclick.irispay.bg/backend/' : 'https://dev.paybyclick.irispay.bg/backend/';
    }

    private function getSdkUrls()
    {
        $version = $this->config->get('payment_irispay_sdk_version');

        if ($version === 'dev') {
            return [
                'js' => 'https://websdk.infn.dev/assets/irispay-ui/elements.js',
                'css' => 'https://websdk.infn.dev/assets/irispay-ui/styles.css'
            ];
        }

        // Production (Iris Pay)
        return [
            'js' => 'https://websdk.irispay.bg/assets/irispay-ui/elements.js',
            'css' => 'https://websdk.irispay.bg/assets/irispay-ui/styles.css'
        ];
    }

    private function getUserHash($public_hash)
    {
        $url = rtrim($this->getBackendUrl(), '/') . '/api/8/signup/public';
        $payload = ['publicHash' => $public_hash];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ['accept: application/json', 'Content-Type: application/json'],
            CURLOPT_TIMEOUT => 10
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            $this->log("[ERROR] getUserHash API failed. HTTP Code: " . $httpCode . ", Response: " . $response);
            return false;
        }
        $data = json_decode($response, true);
        return $data['userHash'] ?? false;
    }

    private function getHookHash($currency, $orderId, $sum, $webhookUrl)
    {
        $url = rtrim($this->getPayByClickBackendUrl(), '/') . '/payment/plugin/create';
        $apiKey = $this->config->get('payment_irispay_api_key');

        $payload = [
            'currency' => $currency,
            'description' => (string) $orderId,
            'key' => $apiKey,
            'orderId' => (string) $orderId,
            'sum' => (float) $sum,
            'hookUrl' => $webhookUrl,
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'accept: application/json',
                'Content-Type: application/json',
            ],
            CURLOPT_TIMEOUT => 10
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            $this->log("[ERROR] getHookHash API failed. HTTP Code: " . $httpCode . ", Response: " . $response);
            return false;
        }
        return json_decode($response, true);
    }

    private function getPaymentStatus($hookHash)
    {
        // Deprecated old API check
        return ['status' => 'UNKNOWN'];
    }
}
