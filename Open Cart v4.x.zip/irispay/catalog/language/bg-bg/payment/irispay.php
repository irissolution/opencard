<?php
// Heading
$_['heading_title'] = 'Плащане с Iris Pay';
$_['button_confirm'] = 'Потвърди поръчката';
$_['text_loading'] = 'Зареждане...';
