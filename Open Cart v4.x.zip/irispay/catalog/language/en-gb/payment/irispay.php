<?php
// Heading
$_['heading_title'] = 'Iris Pay Payment';
$_['button_confirm'] = 'Confirm Order';
$_['text_loading'] = 'Loading...';
