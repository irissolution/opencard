<?php
namespace Opencart\Admin\Controller\Extension\Irispay\Payment;

class Irispay extends \Opencart\System\Engine\Controller
{
    public function index(): void
    {
        $this->load->language('extension/irispay/payment/irispay');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/irispay/payment/irispay', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['save'] = $this->url->link('extension/irispay/payment/irispay|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

        $data['payment_irispay_api_key'] = $this->config->get('payment_irispay_api_key');
        $data['payment_irispay_environment'] = $this->config->get('payment_irispay_environment');
        $data['payment_irispay_sdk_version'] = $this->config->get('payment_irispay_sdk_version');
        $data['payment_irispay_order_status_id'] = $this->config->get('payment_irispay_order_status_id');

        $data['payment_irispay_status'] = $this->config->get('payment_irispay_status');
        $data['payment_irispay_sort_order'] = $this->config->get('payment_irispay_sort_order');

        $this->load->model('localisation/order_status');
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/irispay/payment/irispay', $data));
    }

    public function save(): void
    {
        $this->load->language('extension/irispay/payment/irispay');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/irispay/payment/irispay')) {
            $json['error']['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['payment_irispay_api_key']) {
            $json['error']['api_key'] = $this->language->get('error_api_key');
        }

        if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('payment_irispay', $this->request->post);
            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void
    {
        if ($this->user->hasPermission('modify', 'extension/irispay/payment/irispay')) {
            $this->load->model('setting/event');

            // Fix for OC 4.x addEvent signature
            $event_data = [
                'code' => 'irispay_sdk',
                'description' => 'Catalog IRIS Pay SDK Injection',
                'trigger' => 'catalog/view/common/header/before',
                'action' => 'extension/irispay/payment/irispay.header',
                'status' => true,
                'sort_order' => 0
            ];

            $this->model_setting_event->addEvent($event_data);
        }
    }

    public function uninstall(): void
    {
        if ($this->user->hasPermission('modify', 'extension/irispay/payment/irispay')) {
            $this->load->model('setting/event');
            $this->model_setting_event->deleteEventByCode('irispay_sdk');
        }
    }
}
