<?php
// Heading
$_['heading_title'] = 'Iris Pay Payment';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Iris Pay payment module!';
$_['text_edit'] = 'Edit Iris Pay Payment';
$_['text_irispay'] = '<a href="https://irispay.bg/" target="_blank"><img src="https://irispay.bg/resource/public/image/iris-logo.svg" alt="Iris Pay" title="Iris Pay" style="border: 1px solid #EEEEEE; height: 25px;" /></a>';
$_['text_sandbox'] = 'Sandbox';
$_['text_live'] = 'Live';
$_['text_sdk_dev'] = 'Developer (Infn Dev)';
$_['text_sdk_prod'] = 'Production (Iris Pay)';

// Entry
$_['entry_api_key'] = 'API Key';
$_['entry_environment'] = 'Environment';
$_['entry_sdk_version'] = 'SDK Version';
$_['entry_order_status'] = 'Order Status';

$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';

// Help
$_['help_api_key'] = 'Enter your Iris Pay API Key.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify payment Iris Pay!';
$_['error_api_key'] = 'API Key required!';
