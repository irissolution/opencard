<?php
// Heading
$_['heading_title'] = 'Iris Pay Payment';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success'] = 'Успех: Променихте платежния модул на Iris Pay!';
$_['text_edit'] = 'Редактиране на Iris Pay Payment';
$_['text_irispay'] = '<a href="https://irispay.bg/" target="_blank"><img src="https://irispay.bg/resource/public/image/iris-logo.svg" alt="Iris Pay" title="Iris Pay" style="border: 1px solid #EEEEEE; height: 25px;" /></a>';
$_['text_sandbox'] = 'Тестова среда (Sandbox)';
$_['text_live'] = 'Реална среда (Live)';
$_['text_sdk_dev'] = 'Developer (Infn Dev)';
$_['text_sdk_prod'] = 'Production (Iris Pay)';

// Entry
$_['entry_api_key'] = 'API Key';
$_['entry_environment'] = 'Среда';
$_['entry_sdk_version'] = 'Версия на SDK';
$_['entry_order_status'] = 'Статус на поръчката';

$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Подредба';

// Help
$_['help_api_key'] = 'Въведете своя Iris Pay API Key.';

// Error
$_['error_permission'] = 'Внимание: Нямате права за редакция на плащането с Iris Pay!';
$_['error_api_key'] = 'API Key е задължителен!';
